#include "memory.h"
#include "os.h"
#include <stdio.h>
#include <string.h>

char memory[MEMSIZE];

void memory_init(void) {
    memset(memory, 0, sizeof(memory));
}

uint8_t mem_read_byte_phys(int phys_addr) {
    if (phys_addr < 0 || phys_addr >= MEMSIZE) return 0;
    return (uint8_t)memory[phys_addr];
}

void mem_write_byte_phys(int phys_addr, uint8_t val) {
    if (phys_addr < 0 || phys_addr >= MEMSIZE) return;
    memory[phys_addr] = (char)val;
}

int32_t mem_read_32(int proc_id, uint32_t logical_addr) {
    uint32_t b[4];
    for (int i = 0; i < 4; i++) {
        int pa = getPhysicallAddress(proc_id, 0, logical_addr + i);
        if (pa < 0 || pa >= MEMSIZE) return 0;
        b[i] = (uint8_t)memory[pa];
    }
    return (int32_t)(b[0] | (b[1] << 8) | (b[2] << 16) | (b[3] << 24));
}

void mem_write_32(int proc_id, uint32_t logical_addr, int32_t value) {
    for (int i = 0; i < 4; i++) {
        int pa = getPhysicallAddress(proc_id, 0, logical_addr + i);
        if (pa >= 0 && pa < MEMSIZE) {
            memory[pa] = (char)((value >> (i * 8)) & 0xFF);
        }
    }
}